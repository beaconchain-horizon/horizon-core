# Horizon Agency Agents — Customized Pack

A Horizon-specific agent pack designed around Horizon Core's two domains:

1. Inter-bank financial settlement: ledger, blockchain, licensing and transaction integrity.
2. Industrial monitoring/control: oil, gas, petrochemical and steel sensor environments, including air-gapped deployments.

## Design principles
- Offline-first and air-gap aware
- Go 1.24 compatibility for Horizon Core tooling
- ECDSA signatures, SHA-256 and Merkle proofs
- AES-GCM for data-at-rest where appropriate
- Hardware-bound licensing and enforcement
- PostgreSQL online backend + SQLite edge/offline cache where applicable
- Evidence-first security reviews and reproducible benchmarks
- No invented test results or security claims

## Agents
- core/horizon-architect.md
- security/horizon-crypto-security.md
- security/horizon-license-security.md
- security/horizon-threat-modeler.md
- finance/horizon-settlement-engineer.md
- industrial/horizon-sensor-edge-engineer.md
- engineering/horizon-go-reviewer.md
- engineering/horizon-performance-engineer.md
- engineering/horizon-test-engineer.md
- ops/horizon-airgap-deployment.md
- product/horizon-technical-product.md

These are prompts/instructions, not autonomous deployment code. Validate all security-sensitive output with tests and independent review.
