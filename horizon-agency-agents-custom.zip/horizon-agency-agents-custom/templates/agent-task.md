# Horizon Agent Task Template

## Objective

## Repository / component

## Constraints
- Go version:
- Offline/air-gap:
- Database:
- Security boundary:

## Evidence available

## Required changes

## Acceptance tests

## Risks / rollback

## Output format
1. Findings
2. Files to change
3. Exact implementation plan
4. Tests
5. Evidence and limitations
